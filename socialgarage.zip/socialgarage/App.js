import { StatusBar } from 'expo-status-bar';
import React, { useState, useContext, useEffect, useRef } from 'react';

import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import 'react-native-gesture-handler'

import MaterialTabbedPageNavigator from './Pages/MaterialTabbedPageNavigator';
import LoginPage from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage';
import UserContextProvider, { UserContext } from './Contexts/UserContextProvider';
import WarningLightsContextProvider from './Contexts/WarningLightsContextProvider';
import GaragesContextProvider from './Contexts/GaragesContextProvider';
import WelcomePage from './Pages/WelcomePage';
import AddCar from './Pages/AddCar';
import ProfilePage from './Pages/ProfilePage';
import ProfileEachCar from './Pages/ProfileEachCar';
import TahzukaCar from './Pages/TahzukaCar';
import BulbsCar from './Pages/BulbsCar';
import AddMaintenance from './Pages/AddMaintenance';
import ProfileEachMaintenance from './Pages/ProfileEachMaintenance';
import SocialFeedPage from './Pages/SocialFeedPage';
import ProfileEachCarSocial from './Pages/ProfileEachCarSocial';
import UploadImageSocial from './Pages/UploadImageSocial';
import EachCardPost from './Pages/EachCardPost';
import SocialUserPublicCars from './Pages/SocialUserPublicCars';
import ProfileEachCarSocialGuest from './Pages/ProfileEachCarSocialGuest';
import SearchPageByCar from './Pages/SearchPageByCar';
import FollowingList from './Pages/FollowingList';
import FollowersList from './Pages/FollowersList';
import SalePage from './Pages/SalePage';
import SalePageDetailsPage from './Pages/SalePageDetailsPage';
import EditSalePage from './Pages/EditSalePage';
import SuccessAnimationPage from './Pages/SuccessAnimationPage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import EditPost from './Pages/EditPost';
import CarsBeforeGarages from './Pages/Garage/CarsBeforeGarages';
import GaragesPage from './Pages/Garage/GaragesPage';
import EachGarageDetails from './Pages/Garage/EachGarageDetails';



const Stack = createNativeStackNavigator();

function App() {


  return (
    <SafeAreaProvider>
      <UserContextProvider>
        <GaragesContextProvider>
          <WarningLightsContextProvider>
            <AppContent />
          </WarningLightsContextProvider>
        </GaragesContextProvider>
      </UserContextProvider>
    </SafeAreaProvider>
  );
}

function AppContent() {


  const insets = useSafeAreaInsets();



  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="WelcomePage" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="WelcomePage" component={WelcomePage} />
          <Stack.Screen name="LoginPage" component={LoginPage} />
          <Stack.Screen name="RegisterPage" component={RegisterPage} />
          <Stack.Screen name="TabbedPageNavigator" component={MaterialTabbedPageNavigator} />
          <Stack.Screen name="AddCar" component={AddCar} />
          <Stack.Screen name="ProfilePage" component={ProfilePage} />
          <Stack.Screen name="ProfileEachCar" component={ProfileEachCar} />
          <Stack.Screen name="TahzukaCar" component={TahzukaCar} />
          <Stack.Screen name="BulbsCar" component={BulbsCar} />
          <Stack.Screen name="AddMaintenance" component={AddMaintenance} />
          <Stack.Screen name="ProfileEachMaintenance" component={ProfileEachMaintenance} />
          <Stack.Screen name="SocialFeedPage" component={SocialFeedPage} />
          <Stack.Screen name="ProfileEachCarSocial" component={ProfileEachCarSocial} />
          <Stack.Screen name="ProfileEachCarSocialGuest" component={ProfileEachCarSocialGuest} />
          <Stack.Screen name="UploadImageSocial" component={UploadImageSocial} />
          <Stack.Screen name="EachCardPost" component={EachCardPost} />
          <Stack.Screen name="SocialUserPublicCars" component={SocialUserPublicCars} />
          <Stack.Screen name="SearchPageByCar" component={SearchPageByCar} />
          <Stack.Screen name="FollowingList" component={FollowingList} />
          <Stack.Screen name="FollowersList" component={FollowersList} />
          <Stack.Screen name="SalePage" component={SalePage} />
          <Stack.Screen name="SalePageDetailsPage" component={SalePageDetailsPage} />
          <Stack.Screen name="EditSalePage" component={EditSalePage} />
          <Stack.Screen name="SuccessAnimationPage" component={SuccessAnimationPage} />
          <Stack.Screen name="EditPost" component={EditPost} />
          <Stack.Screen name="CarsBeforeGarages" component={CarsBeforeGarages} />
          <Stack.Screen name="GaragesPage" component={GaragesPage} />
          <Stack.Screen name="EachGarageDetails" component={EachGarageDetails} />







        </Stack.Navigator>
      </NavigationContainer>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});

export default App;
