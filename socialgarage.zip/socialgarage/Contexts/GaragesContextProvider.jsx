import React, { createContext, useEffect, useState } from 'react';

export const GaragesContext = createContext();

export default function GaragesContextProvider(props) {
    const [garages, setGarages] = useState([]);


    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    useEffect(() => {
        const loadGarages = async () => {
            try {
                const response = await fetch('https://socialgarage.onrender.com/api/garages');
                const data = await response.json();
                setGarages(data);
            } catch (error) {
                console.error(error);
            }
        };
        loadGarages();
    }, []);

    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */




    return (
        <GaragesContext.Provider value={{ garages }}>
            {props.children}
        </GaragesContext.Provider>
    );
}
