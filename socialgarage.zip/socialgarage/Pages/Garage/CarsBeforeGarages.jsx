import React, { useContext, useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { UserContext } from '../../Contexts/UserContextProvider';

export default function CarsBeforeGarages() {
  const navigation = useNavigation();
  const { currentUser } = useContext(UserContext);

  const navigateToGarage = (car) => {
    navigation.navigate('GaragesPage', { carData: car });
  };


  return (
    <ScrollView style={styles.container}>
      <View style={styles.container}>
        <Text style={styles.sectionHeading}>בחר רכב לטיפול</Text>

        {currentUser && currentUser.cars && currentUser.cars.length > 0 ? (
          currentUser.cars.map((car, index) => (
            <TouchableOpacity
              key={index}
              style={styles.carContainer}
              onPress={() => navigateToGarage(car)}
            >
              <Image style={styles.carImage} source={{ uri: car.image }} />

              <Text style={styles.carName}>{car.manufacturer} {car.model}{car.nickname ? ` (${car.nickname})` : ''}</Text>
            </TouchableOpacity>
          ))
        ) : (
          <Text style={styles.noCarsText}>No cars available</Text>
        )}

      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,

  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  sectionHeading: {
    fontSize: 18,
    marginTop: 20,
    marginBottom: 10,
    fontWeight: 'bold',
    textAlign: "right",
  },
  carContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    backgroundColor: '#ff8837',
    borderRadius: 42,
    justifyContent: 'space-between',
    paddingRight: '5%',
  },
  carImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  carName: {
    fontSize: 16,
  },
  noCarsText: {
    fontSize: 16,
    fontStyle: 'italic',
  },







});
