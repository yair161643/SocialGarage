import React, { useContext, useState } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, Image, Button, StyleSheet } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';

const SearchPage = () => {
  const navigation = useNavigation();
  const { users, currentUser } = useContext(UserContext);
  const [searchInput, setSearchInput] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);




  const defaultProfileImage = 'https://static.hudl.com/users/prod/5499830_8e273ea3a64448478f1bb0af5152a4c7.jpg';

  const handleSearchInputChange = (text) => {
    setSearchInput(text);
    const filtered = users.filter(user =>
      user.name.toLowerCase().includes(text.toLowerCase())
    );
    setFilteredUsers(filtered);
  };

  const handleUserPress = async (item) => {
    if (currentUser._id === item._id) {
      navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
    } else {
      navigation.navigate('SocialUserPublicCars', { userId: item._id, userName: item.name, profileImage: item.profileImage });
    }
  };

  const navigateToSearchPageByCar = () => {
    navigation.navigate('SearchPageByCar'); // Use the correct screen name
  };

  return (
    <View style={styles.container}>
      <Button title="Search By Car" onPress={navigateToSearchPageByCar} />

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="הכנס שם משתמש"
          value={searchInput}
          onChangeText={handleSearchInputChange}
        />
        <View style={styles.border} />
        <Text style={styles.label}>שם משתמש</Text>
      </View>

      {searchInput.length > 0 && (
        <FlatList
          data={filteredUsers}
          keyExtractor={user => user._id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.userButton}
              onPress={() => handleUserPress(item)}
            >
              <Image
                source={{ uri: item.profileImage || defaultProfileImage }}
                style={styles.userImage}
              />
              <Text style={[styles.userName, { fontWeight: 'bold' }]}>{item.name}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#ccc',
    paddingHorizontal: 16,
  },
  input: {
    flex: 3,
    textAlign: 'right',
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  border: {
    width: 1,
    height: '100%',
    backgroundColor: '#ccc',
  },
  label: {
    flex: 1,
    paddingVertical: 8,
    fontWeight: 'bold',
    textAlign: 'right', // Align the text to the right
  },
  userButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 16,
    marginBottom: 24,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  userImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 16,
  },
  userName: {
    fontSize: 18,
  },
});

export default SearchPage;
