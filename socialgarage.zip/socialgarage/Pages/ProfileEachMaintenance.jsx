import React, { useState, useContext } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Alert, Modal } from 'react-native';
import { useNavigation } from '@react-navigation/native';




export default function ProfileEachMaintenance({ route }) {
    const navigation = useNavigation();
    const { carData } = route.params;
    const [modalVisible, setModalVisible] = useState(false);










    return (
        <View style={styles.container}>


            <Text style={styles.tipulName}>טיפול: {carData.name}</Text>
            <Text style={styles.tipulDate}>התבצע בתאריך: {carData.date}</Text>

            <View style={styles.hr} />



            <Text style={styles.textTmunatKabala}>תמונת קבלה</Text>
            <TouchableOpacity style={styles.biggerCarImage} onPress={() => setModalVisible(true)}>
                <Image style={styles.CarImage} source={{ uri: carData.image }} />
            </TouchableOpacity>

            {/* הצגה של תמונה בגדול ברגע לחיצה */}
            <Modal visible={modalVisible} transparent={true} onRequestClose={() => setModalVisible(false)}>
                <View style={styles.modalContainer}>
                    <Image style={styles.enlargedCarImage} source={{ uri: carData.image }} />
                    <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
                        <Text style={styles.closeButtonText}>סגור</Text>
                    </TouchableOpacity>
                </View>
            </Modal>

            {/* סוף אירוע הגדלת תמונה */}



        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        alignItems: 'center',
        marginVertical: 10,
        padding: 20,
        elevation: 5,
        marginTop: '7%',
        width: '100%',
        alignSelf: 'center',
    },
    tipulName: {
        fontSize: 25,
        fontWeight: 'bold',
        color: '#333',
    },
    tipulDate: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    hr: {
        borderBottomWidth: 1,
        borderBottomColor: '#aaa',
        marginVertical: 10,
        width: "100%",
    },
    biggerCarImage: {
        width: '90%',
        height: '60%',
    },
    CarImage: {
        width: '100%',
        height: '150%',
        resizeMode: 'contain',
    },
    modalContainer: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    closeButton: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
    },
    closeButtonText: {
        color: 'black',
        fontWeight: 'bold',
    },
    enlargedCarImage: {
        width: '97%',
        height: '75%',
        resizeMode: 'contain',
    },
    textTmunatKabala: {
        fontSize: 18,
        textDecorationLine: 'underline',
        marginBottom: "5%",

    },

});
