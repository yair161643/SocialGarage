import React, { useContext, useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Alert, ScrollView, Dimensions } from 'react-native'; // שים לב שהוספתי גם את 'Dimensions'

import { WarningLightsContext } from '../Contexts/WarningLightsContextProvider';

const BulbsCar = () => {
  const { lights } = useContext(WarningLightsContext);
  const [selectedLight, setSelectedLight] = useState(null);

  const handleLightPress = (light) => {
    setSelectedLight(light.id === selectedLight?.id ? null : light);
  };

  const showDescriptionAlert = (light) => {
    Alert.alert(light.name, light.description);
  };

  // קביעת מספר הבורות בכל שורה
  const numColumns = 3;
  const itemWidth = Dimensions.get('window').width / numColumns - 20;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {lights.map((light) => (
        <TouchableOpacity
          key={light.id}
          onPress={() => {
            handleLightPress(light);
            showDescriptionAlert(light);
          }}
          style={[styles.bulbContainer, selectedLight?.id === light.id, { width: itemWidth }]}
        >
          <Image source={{ uri: light.img }} style={styles.bulbImage} />
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap', // הוספת גזירת רשת
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 20,
  },
  bulbContainer: {
    padding: 10,
    borderRadius: 10,
    backgroundColor: 'transparent',
    marginBottom: 10, // מרווח בין הבורות
    alignItems:'center',
  },
  bulbImage: {
    width: 85,
    height: 85,
    resizeMode: 'contain',
    backgroundColor: 'black',
    borderRadius: 10,

  },
});

export default BulbsCar;
