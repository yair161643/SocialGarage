import React, { useState, useContext, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';


export default function LoginPage(props) {
  const navigation = useNavigation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const { fromLoginToCheckIfExist, currentUser } = useContext(UserContext);
  const slideAnim = useRef(new Animated.Value(5)).current;




  useEffect(() => {
    Animated.timing(slideAnim, {
      toValue: 0,
      duration: 1200,
      useNativeDriver: true,
    }).start();
  }, [slideAnim]);


  const handleLogin = async () => {
    const emailWithoutSpaces = email.replace(/\s+/g, '');
    const userExists = await fromLoginToCheckIfExist(emailWithoutSpaces, password);
    if (userExists) {
      // ברגע של התחברות זה ישמור את הנתונים בשביל לבדוק אם המכשיר התחבר כבר
      await AsyncStorage.setItem('userEmail', emailWithoutSpaces);
      await AsyncStorage.setItem('userPassword', password);

      navigation.reset({
        index: 0,
        routes: [{ name: 'TabbedPageNavigator' }],
      });

    } else {
      alert('משתמש אינו קיים');
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>התחברות</Text>

      {/* Slide-in animation for email input */}
      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, 100], // Slide in from right
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="מייל"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          textAlign="right"
        />
      </Animated.View>

      {/* Slide-in animation for password input */}
      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -100], // Slide in from left
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="סיסמה"
          secureTextEntry={true}
          value={password}
          onChangeText={setPassword}
          textAlign="right"
        />
      </Animated.View>

      <TouchableOpacity
        style={styles.button}
        onPress={handleLogin}
      >
        <Text style={styles.buttonText}>התחברות</Text>
      </TouchableOpacity>

      <View style={styles.registerContainer}>
        <TouchableOpacity
          onPress={() => props.navigation.navigate('RegisterPage')}
        >
          <Text style={styles.registerButton}> להרשמה </Text>
        </TouchableOpacity>
        <Text style={styles.registerText}>אין לך חשבון? </Text>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'top',
    paddingTop: "20%",
  },
  heading: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 40,
  },
  inputContainer: {
    width: '80%',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ff5f04',
    borderRadius: 20,
    padding: 10,
    width: '100%',
  },
  button: {
    backgroundColor: '#ff5f04',
    borderRadius: 20,
    padding: 10,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: 'black',
    fontWeight: 'bold',
  },
  registerContainer: {
    flexDirection: 'row',
    marginTop: 20,
  },
  registerText: {
    marginRight: 10,
  },
  registerButton: {
    color: '#ff5f04',
    fontWeight: 'bold',
    textDecorationLine: 'underline',

  },
});
