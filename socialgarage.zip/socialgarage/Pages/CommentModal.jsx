import React, { useState, useContext } from 'react';
import { View, Text, Modal, StyleSheet, FlatList, TextInput, TouchableOpacity } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { UserContext } from '../Contexts/UserContextProvider';

const CommentModal = ({ comments, card, onClose }) => {
    const { addCommentToCard, currentUser, addCommentToUser } = useContext(UserContext);
    const [newComment, setNewComment] = useState('');

    const handleAddComment = async () => {
        if (newComment.trim() !== '') {
            const commentData = {
                userName: currentUser.name,
                comment: newComment.trim(),
            };

            const success = await addCommentToCard(card._id, commentData);
            await addCommentToUser(card.owner.id, card.carNumber, card._id, commentData)

            if (success) {
                setNewComment('');

                // Close the modal after successfully adding the comment
                onClose();
            }
        }
    };


    return (
        <ScrollView>
            <Modal visible={!!comments} transparent={true} animationType="fade">
                <View style={styles.modalContainer}>
                    <View style={styles.modalContent}>
                        <Text style={styles.modalTitle}>Comments</Text>


                        <FlatList
                            data={comments}
                            keyExtractor={(item, index) => index.toString()}
                            renderItem={({ item }) => (
                                <View style={styles.commentItem}>
                                    <Text style={styles.commentText}>
                                        <Text style={styles.userName}>{item.userName}:</Text> {item.comment.replace(/\n/g, '\n\n')}
                                    </Text>
                                </View>
                            )}
                        />

                        <TextInput
                            style={styles.commentInput}
                            placeholder="Add a comment..."
                            value={newComment}
                            onChangeText={setNewComment}
                        />
                        <TouchableOpacity style={styles.addButton} onPress={handleAddComment}>
                            <Text style={styles.addButtonText}>Add Comment</Text>
                        </TouchableOpacity>

                        <Text style={styles.closeButton} onPress={onClose}>
                            Close
                        </Text>
                    </View>
                </View>
            </Modal>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',

    },
    modalContent: {
        backgroundColor: '#fff',
        padding: 20,
        borderRadius: 10,
        width: '100%',
        maxHeight: '60%',
        minHeight: '60%',

    },
    modalTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
        alignSelf: 'center',
    },
    commentItem: {
        marginBottom: 10,
    },
    commentText: {
        fontSize: 16,
        marginBottom: 5,
    },
    closeButton: {
        fontSize: 16,
        color: 'black',
        textAlign: 'center',
        marginTop: 20,
    },
    hr: {
        borderBottomWidth: 1,
        borderBottomColor: '#aaa',
        marginVertical: 10,
        width: "100%",
    },
    userName: {
        fontWeight: 'bold',
    },
    commentInput: {
        height: 40,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        padding: 8,
        marginBottom: 10,
    },
    addButton: {
        backgroundColor: '#93c29f',
        padding: 10,
        borderRadius: 5,
        alignItems: 'center',
        marginBottom: 10,
    },
    addButtonText: {
        color: 'white',
        fontWeight: 'bold',
    },

});

export default CommentModal;
