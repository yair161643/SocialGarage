import React, { useState, useContext, useEffect, useRef } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Alert, Modal, Platform, ActivityIndicator, Switch, RefreshControl } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import cheerio from 'cheerio';
import { useNavigation } from '@react-navigation/native';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { ScrollView } from 'react-native-gesture-handler';
import { Dimensions } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { AntDesign } from '@expo/vector-icons'; // Import the kebab menu icon
import LottieView from 'lottie-react-native'; // Import LottieView



export default function ProfileEachCarSocial({ route }) {

    const navigation = useNavigation();
    const { carData } = route.params;
    const { currentUser, addNewCard, changeToPrivate, changeToPublic, deleteCardsByCarNumber, uploadTheLastAfterPublic } = useContext(UserContext);
    const [modalVisible, setModalVisible] = useState(false);
    const [image, setImage] = useState(null);
    const [loading, setLoading] = useState(false); // Add loading state
    const [isPrivate, setIsPrivate] = useState(carData.isPrivate);
    const [showConfirmationModal, setShowConfirmationModal] = useState(false);
    const [newPrivacyState, setNewPrivacyState] = useState(isPrivate);
    const [confirmationMessage, setConfirmationMessage] = useState('');
    const [totalLikes, setTotalLikes] = useState(0);
    const [refreshing, setRefreshing] = useState(false);
    const [cards, setCards] = useState(carData.cards);



    useEffect(() => {
        fetchTotalLikes();
    }, []);




    const fetchTotalLikes = async () => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/total-likes/${carData.carNumber}`);
            const data = await response.json();
            setTotalLikes(data.totalLikes);
        } catch (error) {
            console.error('Error fetching total likes:', error);
        }
    };




    const windowWidth = Dimensions.get('window').width;


    const navigateToProfileEachCar = () => {
        navigation.navigate('ProfileEachCar', { carData });
    };




    /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */
    const openImagePickerAsync = async () => {
        if (Platform.OS !== 'web') {
            const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (permissionResult.granted === false) {
                alert('נא לאשר גישה לגלריה ולמצלמה');
                return;
            }
        }

        Alert.alert(
            'בחר מקור תמונה',
            'בחר מקור לתמונה',
            [
                {
                    text: 'מצלמה',
                    onPress: () => launchCamera(),
                },
                {
                    text: 'גלריה',
                    onPress: () => launchGallery(),
                },
                {
                    text: 'ביטול',
                    style: 'cancel',
                },
            ],
            { cancelable: true }
        );
    };
    const launchCamera = async () => {
        let permissionResult = await ImagePicker.requestCameraPermissionsAsync();

        if (permissionResult.granted === false) {
            alert("נדרשת הרשאה לגשת למצלמה!");
            return;
        }

        let pickerResult = await ImagePicker.launchCameraAsync({ base64: true, quality: 1.0 });

        if (!pickerResult.canceled) {
            const data = await ImageUploader(pickerResult.assets[0].base64);
            navigation.navigate('UploadImageSocial', { carData: carData, imageToUpload: data });

        }
    };
    //ask for permisstion
    const launchGallery = async () => {
        let permissionResult =
            await ImagePicker.requestMediaLibraryPermissionsAsync();

        if (permissionResult.granted === false) {
            alert("נדרשת הרשאה לגשת לגלריה!");
            return;
        }

        let pickerResult = await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 1.0 });

        if (!pickerResult.canceled) {
            const data = await ImageUploader(pickerResult.assets[0].base64);
            navigation.navigate('UploadImageSocial', { carData: carData, imageToUpload: data });

        }
    };
    const ImageUploader = async (uri) => {
        setLoading(true); // Set loading state to true

        try {

            const response = await fetch(`https://socialgarage.onrender.com/api/users/upload`, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ image: uri }),
            });

            if (!response.ok) {
                throw new Error("Failed to upload image");
            } else {
                const data = await response.json();
                setImage(data);
                setLoading(false); // Set loading state back to false

                return data;
            }

            return;
        } catch (err) {
            console.log(err);
            setLoading(false); // Set loading state back to false in case of an error

        }

    };
    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */




    const handleImagePress = (card) => {
        navigation.navigate('EachCardPost', { cardData: card, carData: carData }); // Adjust the screen name and parameters as needed
    };

    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



    const handlePrivacyChange = async () => {
        if (newPrivacyState) {
            const success = await changeToPrivate(carData.carNumber);
            if (success) {
                await deleteCardsByCarNumber(carData.carNumber); // Delete cards when making the car private
                Alert.alert('שינוי פרטיות לרכב', 'הרכב שלך הפך פרטי.');
            }
        }
        else {
            const success = await changeToPublic(carData.carNumber);
            if (success) {
                const lastCardIndex = carData.cards.length - 1;
                if (carData.cards[lastCardIndex] !== undefined) {

                    await uploadTheLastAfterPublic(carData.cards[lastCardIndex]);
                }
                Alert.alert('שינוי פרטיות לרכב', 'הרכב שלך הפך ציבורי.');
            }
        }

        setIsPrivate(newPrivacyState);
    };

    const fetchCardData = async () => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/${carData.carNumber}/cards`);
            const data = await response.json();
            setCards(data);
            carData.cards = data;
        } catch (error) {
            console.error('Error fetching card data:', error);
        }
    };




    const onRefresh = async () => {
        try {
            setRefreshing(true);
            await fetchTotalLikes(); // Refresh the total likes
            await fetchCardData(); // Fetch the card data here
        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setRefreshing(false);
        }
    };





    return (
        <ScrollView
            refreshControl={
                <RefreshControl
                    refreshing={refreshing}
                    onRefresh={onRefresh}
                    colors={['#ff5f04']} // Customize the loading spinner color
                />
            }
        >


            <View style={styles.container}>
                <View style={styles.coteret}>
                    <Image style={styles.carImage} source={{ uri: carData.image }} />
                    <Text style={styles.carName}> {carData.manufacturer}</Text>
                    <Text style={styles.carName}> {carData.model}</Text>
                    {carData.nickname && <Text style={styles.carName}> {"("}{carData.nickname}{")"}</Text>}
                </View>

                <View style={styles.row}>
                    <TouchableOpacity style={styles.button}>
                        <Text style={styles.buttonText}>פרופיל</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.buttonNotCurrent} onPress={navigateToProfileEachCar}>
                        <Text style={styles.buttonText}>איזור אישי</Text>
                    </TouchableOpacity>

                </View>

                <View style={styles.row}>
                    <Switch
                        trackColor={{
                            false: "#ff5f04", // Track color when switch is off (public)
                            true: "#dcdcdc",  // Track color when switch is on (private)
                        }}
                        thumbColor={isPrivate ? "#dcdcdc" : "#ff5f04"} // Thumb color based on switch state
                        ios_backgroundColor="#dcdcdc" // Background color for iOS
                        onValueChange={() => {
                            setNewPrivacyState(!newPrivacyState);
                            setShowConfirmationModal(true);
                            setConfirmationMessage(
                                newPrivacyState
                                    ? 'האם להפוך את פרופיל הרכב לציבורי?'
                                    : 'האם להפוך את פרופיל הרכב לפרטי?'
                            );
                        }}
                        value={newPrivacyState}
                    />



                    <Text style={styles.privacyText}>
                        {isPrivate ? 'רכב זה פרטי' : 'רכב זה הוא פומבי'}
                    </Text>
                </View>
                <View style={styles.hr} />
                <Text style={styles.totalLikesText}>Total Likes: {totalLikes}</Text>


                <Modal
                    visible={showConfirmationModal}
                    transparent={true}
                    animationType="fade"
                    onRequestClose={() => setShowConfirmationModal(false)}
                >
                    <View style={styles.confirmationModal}>
                        <Text style={styles.confirmationText}>{confirmationMessage}</Text>
                        <View style={styles.confirmationButtons}>
                            <TouchableOpacity
                                style={[styles.confirmationButton, styles.confirmationButtonCancel]}
                                onPress={() => {
                                    setShowConfirmationModal(false);
                                    setNewPrivacyState(isPrivate);
                                }}
                            >
                                <Text style={styles.confirmationButtonText}>ביטול</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={[styles.confirmationButton, styles.confirmationButtonConfirm]}
                                onPress={() => {
                                    setShowConfirmationModal(false);
                                    handlePrivacyChange();
                                }}
                            >
                                <Text style={styles.confirmationButtonText}>אישור</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>


                <Image style={styles.biggerCarImage} source={{ uri: carData.image }} />



                <TouchableOpacity style={styles.uploadButton} onPress={openImagePickerAsync}>
                    <Text style={styles.buttonText}>העלה פוסט</Text>
                </TouchableOpacity>


                {carData.isForSale && (

                    <TouchableOpacity
                        style={styles.uploadButton}
                        onPress={() => navigation.navigate('SalePageDetailsPage', { carData })}
                    >
                        <Text style={styles.buttonText}>צפה בדף מכירה</Text>
                    </TouchableOpacity>
                )}





                {/* <View style={styles.hr} /> */}

                <View style={styles.rowImagesContainer}>
                    {/* Divide the cards into rows with 3 images per row */}
                    {cards.slice().reverse().reduce((rows, card, index) => {
                        if (index % 3 === 0) {
                            rows.push([]);
                        }
                        rows[rows.length - 1].push(card);
                        return rows;
                    }, []).map((row, rowIndex) => (
                        <View key={rowIndex} style={styles.rowImages}>
                            {row.map((card, cardIndex) => (
                                <TouchableOpacity
                                    key={cardIndex}
                                    style={styles.imageInRow}
                                    onPress={() => handleImagePress(card)}
                                >
                                    <Image
                                        style={styles.imageInRowa}
                                        source={{ uri: card.image }}
                                    />
                                </TouchableOpacity>
                            ))}
                        </View>
                    ))}
                </View>


                <Modal
                    visible={loading}
                    transparent={true}
                    animationType="fade"
                    onRequestClose={() => setLoading(false)}
                >
                    <View style={styles.loadingModal}>
                        <View style={styles.uploadButtonContent}>
                            <LottieView
                                source={require('../lottieanimations/theAddphotoLoad.json')}
                                autoPlay
                                loop
                                style={styles.lottieAnimation}
                            />

                        </View>
                    </View>
                </Modal>





            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        alignItems: 'center',
        marginVertical: 10,
        padding: 20,
        elevation: 5,
    },
    coteret: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        textAlign: "center",
        marginBottom: 10,

    },
    carImage: {
        width: 60,
        height: 60,
        borderRadius: 50,
        marginRight: 10,
    },
    carName: {
        fontSize: '25%',
        fontWeight: 'bold',
        color: '#333',
    },

    hr: {
        borderBottomWidth: 1,
        borderBottomColor: '#aaa',
        marginVertical: 10,
        width: "100%",
    },
    biggerCarImage: {
        width: Dimensions.get('window').width * 0.8, // Set 70% of the window width
        height: Dimensions.get('window').width * 0.5, // Set 70% of the window width to maintain a square shape
        resizeMode: 'cover', // Use 'cover' to make the image fill the square without stretching
        marginBottom: 10,
    },
    button: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        width: '40%',
        alignItems: 'center',
    },
    buttonNotCurrent: {
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 10,
        width: '40%',
        alignItems: 'center',
    },

    buttonText: {
        color: 'black',
        fontWeight: 'bold',
    },
    row: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",

    },
    closeButton: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
    },
    closeButtonText: {
        color: 'black',
        fontWeight: 'bold',
    },
    enlargedCarImage: {
        width: 350,
        height: 350,
        resizeMode: 'contain',
    },
    privacyText: {
        fontSize: 16,
        color: '#333',
        marginLeft: 10,
    },

    uploadButton: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
        width: '80%',
        alignItems: 'center',
    },
    uploadButtonContent: {
        flexDirection: 'row',
        alignItems: 'center', // Center content vertically
        justifyContent: 'center', // Center content horizontally
    },
    lottieAnimation: {
        width: 100,
        height: 100,
        marginLeft: 10, // Adjust this value to move it to the right
        marginRight: 20,
    },
    buttonText: {
        color: 'black',
        fontWeight: 'bold',
    },


    rowImagesContainer: {
        flexDirection: 'column',
        alignItems: 'center',
        width: '90%', // Each row takes 90% of the window width
    },
    rowImages: {
        flexDirection: 'row',
        justifyContent: 'center',
        width: '100%', // Each row takes 100% of the rowImagesContainer width
    },
    imageInRow: {
        width: '40%', // Each image takes 30% of the row width
        aspectRatio: 1, // To maintain a square shape
        resizeMode: 'cover',
        margin: 2,
    },
    imageInRowa: {
        width: '100%', // Each image takes 30% of the row width
        aspectRatio: 1, // To maintain a square shape

    },
    totalLikesText: {
        fontSize: 20,       // Increase the font size
        fontWeight: 'bold', // Make the text bold
        marginTop: 10,      // Add margin to separate from the previous element
        marginBottom: 10,   // Add margin to separate from the next element
        color: '#333',      // Set the color
    },
    loadingModal: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    buttonRed: {
        backgroundColor: 'red',
        borderRadius: 20,
        padding: 10,
        width: '40%',
        alignItems: 'center',
    },
    buttonGreen: {
        backgroundColor: 'green',
        borderRadius: 20,
        padding: 10,
        width: '40%',
        alignItems: 'center',
    },
    kebabMenu: {
        position: 'absolute',
        top: 10,
        right: 10,
        zIndex: 1,
    },
    kebabMenuDropdown: {
        position: 'absolute',
        top: 40,
        right: 10,
        backgroundColor: 'white',
        elevation: 5,
        borderRadius: 5,
        zIndex: 2,
    },
    kebabMenuItem: {
        padding: 10,
    },
    kebabMenuItemText: {
        color: 'black',
        fontWeight: 'bold',
    },

    confirmationModal: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    confirmationText: {
        fontSize: 18,
        marginBottom: 20,
        textAlign: 'center',
        color: 'white',
    },
    confirmationButtons: {
        flexDirection: 'row',
    },
    confirmationButton: {
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 5,
    },
    confirmationButtonCancel: {
        backgroundColor: 'gray',
        marginRight: 10,
    },
    confirmationButtonConfirm: {
        backgroundColor: 'green',
    },
    confirmationButtonText: {
        color: 'white',
        fontWeight: 'bold',
    },

});
