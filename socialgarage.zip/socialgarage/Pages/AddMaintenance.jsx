import React, { useContext, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, TouchableWithoutFeedback, Keyboard, Alert, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import { ScrollView } from 'react-native-gesture-handler';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { format } from 'date-fns';
import { FontAwesome } from 'react-native-vector-icons';


export default function AddMaintenance({ route }) {
    const { carData } = route.params;
    const navigation = useNavigation();
    const { addMaintenanceToUser } = useContext(UserContext);
    const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
    const [name, setName] = useState('');
    const [date, setDate] = useState('');
    const [image, setImage] = useState(null);
    // Inside the component
    const [isLoading, setIsLoading] = useState(false);
    // Inside the component
    const [isImageUploaded, setIsImageUploaded] = useState(false);

    const chooseDate = () => {
        setDatePickerVisibility(true);
    };

    const handleConfirm = (date) => {
        const formattedDate = format(date, 'dd/MM/yyyy');
        setDate(formattedDate);
        setDatePickerVisibility(false);
    };

    const hideDatePicker = () => {
        setDatePickerVisibility(false);
    };

    const handleAddMaintenance = async () => {
        if (name === '' || name === null || date === '' || date === null || image === null) {
            alert("נא מלא את כל השדות")
            return;
        }
        const newMaintenance = {
            name: name,
            date: date,
            image: image,
        };


        const success = await addMaintenanceToUser(carData.carNumber, newMaintenance);

        if (success) {
            const updatedCarData = {
                ...carData,
                tahzuka: [...carData.tahzuka, newMaintenance],
            };

            // Reset the input fields
            setName('');
            setDate('');
            setImage(null);

            // Navigate back to the TahzukaCar and pass the updatedCarData as a parameter
            navigation.navigate('ProfileEachCar', { carData: updatedCarData });
            alert("הוסף בהצלחה")
        }

        else {
            Alert.alert('שגיאה', 'אי אפשר להוסיף טיפול');


        };

    }


    /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */
    const openImagePickerAsync = async () => {
        setIsImageUploaded(false); // Reset the state when the user opens the image picker

        if (Platform.OS !== 'web') {
            const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (permissionResult.granted === false) {
                alert('נא לאשר גישה לגלריה ולמצלמה');
                return;
            }
        }

        Alert.alert(
            'בחר מקור תמונה',
            'בחר מקור לתמונה',
            [
                {
                    text: 'מצלמה',
                    onPress: () => launchCamera(),
                },
                {
                    text: 'גלריה',
                    onPress: () => launchGallery(),
                },
                {
                    text: 'ביטול',
                    style: 'cancel',
                },
            ],
            { cancelable: true }
        );
    };

    const launchCamera = async () => {
        let permissionResult = await ImagePicker.requestCameraPermissionsAsync();

        if (permissionResult.granted === false) {
            alert("נדרשת הרשאה לגשת למצלמה!");
            return;
        }

        let pickerResult = await ImagePicker.launchCameraAsync({ base64: true, quality: 1.0 });

        if (!pickerResult.canceled) {
            await ImageUploader(pickerResult.assets[0].base64);
        }
    };





    //ask for permisstion
    const launchGallery = async () => {
        let permissionResult =
            await ImagePicker.requestMediaLibraryPermissionsAsync();

        if (permissionResult.granted === false) {
            alert("נדרשת הרשאה לגשת לגלריה!");
            return;
        }

        let pickerResult = await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 1.0 });

        if (!pickerResult.canceled) {
            await ImageUploader(pickerResult.assets[0].base64);
        }
    };

    const ImageUploader = async (uri) => {
        try {
            setIsLoading(true);
            const response = await fetch(`https://socialgarage.onrender.com/api/users/upload`, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ image: uri }),
            });
            if (!response.ok) {
                throw new Error("Failed to upload image");
            } else {
                const data = await response.json();
                setImage(data);
                setIsImageUploaded(true); // Set the state to indicate image upload is complete
            }
            setIsLoading(false);
            return;
        } catch (err) {
            console.log(err);
            setIsLoading(false);
        }
    };




    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


    const dismissKeyboard = () => {
        Keyboard.dismiss();
    };

    return (
        <ScrollView>
            <TouchableWithoutFeedback onPress={dismissKeyboard}>
                <View style={styles.container}>
                    <View style={styles.coteret1}>
                        <Image style={styles.carImage1} source={{ uri: carData.image }} />
                        <Text style={styles.carName1}>{carData.manufacturer}</Text>
                        <Text style={styles.carName1}>{carData.model}</Text>
                        {carData.nickname && <Text style={styles.carName1}> {"("}{carData.nickname}{")"}</Text>}
                    </View>
                    <Text style={styles.heading}>הוספת טיפול</Text>

                    <Text style={styles.upText}>שם הטיפול</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="שם הטיפול"
                        value={name}
                        onChangeText={setName}
                        textAlign="right"
                    />

                    <Text style={styles.upText}>תאריך טיפול</Text>
                    <TouchableOpacity style={styles.input} onPress={chooseDate}>
                        <Text style={date ? styles.rightText : styles.placeholderText}>{date || 'בחר תאריך'}</Text>
                    </TouchableOpacity>

                    <DateTimePickerModal
                        isVisible={isDatePickerVisible}
                        mode="date"
                        onConfirm={handleConfirm}
                        onCancel={hideDatePicker}
                    />



                    <TouchableOpacity style={image ? styles.noBackground : styles.imageButton} onPress={openImagePickerAsync}>
                        {isLoading ? (
                            <Text style={styles.buttonText}>Uploading...</Text>
                        ) : image ? (
                            <Image source={{ uri: image }} style={styles.uploadedImage} />
                        ) : (
                            <>
                                <Text style={styles.buttonText}>העלה תמונת קבלה</Text>
                                <FontAwesome style={styles.buttonText} name="upload" color={"black"} size={25} />
                            </>
                        )}
                    </TouchableOpacity>


                    <Text style={styles.noteText}>
                        שימו לב שבתמונה צריך לראות את מספר הרכב ופרטי הטיפול!
                    </Text>


                    <TouchableOpacity style={styles.addButton} onPress={handleAddMaintenance}>
                        <Text style={styles.addButtonText}>הוסף טיפול</Text>
                    </TouchableOpacity>
                </View>
            </TouchableWithoutFeedback>
        </ScrollView>
    );
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        width: '100%',
    },
    noteText: {
        textAlign: 'center',
        fontSize: 16,
        fontWeight: 'bold',
        color: '#ff5f04', // Customize the color as needed
        marginTop: 20, // Adjust the spacing from the above content
    },

    heading: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
    },
    upText: {
        textAlign: 'right',
        marginBottom: 3,
        marginRight: 3,
        fontWeight: 'bold',
    },
    rightText: {
        textAlign: 'right',
        fontWeight: 'bold',
    },
    placeholderText: {
        textAlign: 'right',
        fontStyle: 'italic',
        color: '#999',

    },
    coteret1: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        textAlign: "center",
        marginBottom: 10,
    },
    carImage1: {
        width: 60,
        height: 60,
        borderRadius: 50,
        marginRight: 10,
    },
    carName1: {
        fontSize: '25%',
        fontWeight: 'bold',
        color: '#333',
    },
    input: {
        height: 40,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        marginBottom: 10,
        padding: 10,
        borderColor: '#ff5f04',
        fontWeight: 'bold',
    },
    imageButton: {
        marginTop: 10,
        marginBottom: 10,
        padding: 10,
        borderRadius: 5,  // שנה את הסגנון לעגול
        fontWeight: 'bold',
        textAlign: 'center',  // מרכז את הטקסט באמצעות מיקום הטקסט
        width: '50%',
        alignSelf: 'center',
        backgroundColor: 'lightgray', // צבע רקע חדש לכפתור

    },
    buttonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    imageContainer: {
        alignItems: 'center',
        marginBottom: 10,
    },
    imageText: {
        fontSize: 14,
        marginBottom: 5,
        textAlign: 'center',
    },
    selectedImage: {
        width: 200,
        height: 200,
        borderRadius: 10,
    },
    addButton: {
        marginTop: 20,
        padding: 10,
        backgroundColor: '#ff5f04',
        borderRadius: 10,
        alignSelf: 'center',
    },
    addButtonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'bold',

    },
    uploadedImage: {
        width: 200,
        height: 200,
        borderRadius: 10,
        marginBottom: 10,
        alignSelf: 'center',

    },
    noBackground: {
        backgroundColor: "#0000",
    }

});



