import React, { useState, useContext, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  Animated,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
  Alert,
  Image,
  KeyboardAvoidingView,
  ActivityIndicator,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { UserContext } from '../Contexts/UserContextProvider';


export default function RegisterPage(props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');

  const [isUploading, setIsUploading] = useState(false);
  const [profileImage, setImage] = useState(null);


  const { fromRegisterToUsersList } = useContext(UserContext);

  const slideAnim = useRef(new Animated.Value(5)).current;

  useEffect(() => {
    // Start the slide-in animation when the component mounts
    Animated.timing(slideAnim, {
      toValue: 0,
      duration: 1200,
      useNativeDriver: true,
    }).start();
  }, [slideAnim]);


  const handleRegister = async () => {
    const userAdded = await fromRegisterToUsersList(email, password, name, profileImage);
    if (userAdded) {
      alert("משתמש נוצר בהצלחה");
      props.navigation.navigate('LoginPage');
    }
  };






  /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */
  const openImagePickerAsync = async () => {
    if (Platform.OS !== 'web') {
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (permissionResult.granted === false) {
        alert('נא לאשר גישה לגלריה ולמצלמה');
        return;
      }
    }

    Alert.alert(
      'בחר מקור תמונה',
      'בחר מקור לתמונה',
      [
        {
          text: 'Camera',
          onPress: () => launchCamera(),
        },
        {
          text: 'Gallery',
          onPress: () => launchGallery(),
        },
        {
          text: 'Cancel',
          style: 'cancel',
        },
      ],
      { cancelable: true }
    );
  };




  const launchCamera = async () => {
    let permissionResult = await ImagePicker.requestCameraPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("נדרשת הרשאה לגשת למצלמה!");
      return;
    }

    let pickerResult = await ImagePicker.launchCameraAsync({ base64: true, quality: 1.0 });

    if (!pickerResult.canceled) {
      await ImageUploader(pickerResult.assets[0].base64);
    }
  };





  //ask for permisstion
  const launchGallery = async () => {
    let permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("נדרשת הרשאה לגשת לגלריה!");
      return;
    }

    let pickerResult = await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 1.0 });

    if (!pickerResult.canceled) {
      await ImageUploader(pickerResult.assets[0].base64);
    }
  };


  const ImageUploader = async (uri) => {
    try {
      setIsUploading(true); // Set isUploading to true while the image is being uploaded

      const response = await fetch(`https://socialgarage.onrender.com/api/users/upload`, {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image: uri }),
      });

      if (!response.ok) {
        throw new Error("Failed to upload image");
      } else {
        const data = await response.json();
        setImage(data);
      }

      return;
    } catch (err) {
      console.log(err);
    } finally {
      setIsUploading(false); // Ensure isUploading is set back to false even if an error occurs
    }
  };

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const handleImagePress = () => {
    openImagePickerAsync();
  };





  return (
    <View style={styles.container}>
      <Text style={styles.heading}>הרשמה</Text>


      {isUploading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#ff5f04" />
          <Text style={styles.loadingText}>מעלה תמונה, אנא המתן...</Text>
        </View>
      ) : (
        <TouchableOpacity style={styles.imageButton} onPress={handleImagePress}>
          {profileImage ? (
            <Image source={{ uri: profileImage }} style={styles.selectedImage} />
          ) : (
            <Image source={{ uri: 'https://cdn.discordapp.com/attachments/335474034542247937/1140627978687094865/image.png' }} style={styles.selectedImage} />
          )}
        </TouchableOpacity>
      )}



      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, 100],
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="מייל"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          textAlign="right"
        />
      </Animated.View>


      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -100],
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="כינוי"
          keyboardType="default"
          value={name}
          onChangeText={setName}
          textAlign="right"
        />
      </Animated.View>


      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, 100],
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="סיסמה"
          secureTextEntry={true}
          value={password}
          onChangeText={setPassword}
          textAlign="right"
        />
      </Animated.View>

      <Animated.View style={[
        styles.inputContainer,
        {
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -100],
              })
            },
          ],
        },
      ]}>
        <TextInput
          style={styles.input}
          placeholder="אימות סיסמה"
          secureTextEntry={true}
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          textAlign="right"
        />
      </Animated.View>





      <TouchableOpacity
        style={styles.button}
        onPress={handleRegister}
      >
        <Text style={styles.buttonText}>הרשמה</Text>
      </TouchableOpacity>


      <View style={styles.registerContainer}>
        <TouchableOpacity
          onPress={() => props.navigation.navigate('LoginPage')}
        >
          <Text style={styles.registerButton}> להתחברות </Text>
        </TouchableOpacity>
        <Text style={styles.registerText}>כבר יש לך חשבון? </Text>
      </View>

    </View>
  )
}





const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'top',
    paddingTop: "20%",
  },
  heading: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderColor: '#ff5f04',
    borderRadius: 20,
    padding: 10,
    marginBottom: 20,
    width: '80%',
  },
  input: {
    width: '100%',
  },
  button: {
    backgroundColor: '#ff5f04',
    borderRadius: 20,
    padding: 10,
    width: '80%',
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: 'black',
    fontWeight: 'bold',
  },
  link: {
    marginTop: 20,
  },
  linkText: {
    color: '#007bff',
    textDecorationLine: 'underline',
  },
  registerContainer: {
    flexDirection: 'row',
    marginTop: 20,
  },
  registerText: {
    marginRight: 10,
  },
  registerButton: {
    color: '#ff5f04',
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
  imageButton: {
    marginTop: 10,
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    textAlign: 'center',
    alignItems: 'center', // Center the content horizontally
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  imageText: {
    fontSize: 14,
    marginBottom: 5,
    textAlign: 'center',
  },
  selectedImage: {
    width: 125,
    height: 125,
    borderRadius: 100,
    marginTop: 5,
  },
  buttonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  loadingContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  loadingText: {
    fontSize: 14,
    marginTop: 5,
    textAlign: 'center',
  },



});