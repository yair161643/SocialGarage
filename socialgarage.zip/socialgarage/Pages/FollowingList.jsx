import React, { useContext, useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';

const FollowingList = ({ route }) => {
    const { userId } = route.params;
    const { currentUser } = useContext(UserContext);
    const navigation = useNavigation();

    const [followingList, setFollowingList] = useState([]);

    useEffect(() => {
        // Fetch following list based on userId
        fetchFollowingList();
    }, []);

    const fetchFollowingList = async () => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/${userId}/following`);
            if (!response.ok) {
                throw new Error(`Request failed with status: ${response.status}`);
            }
            const data = await response.json();
            setFollowingList(data);
        } catch (error) {
            console.error('Error fetching following list:', error);
        }
    };

    const renderFollowingItem = ({ item }) => (
        <TouchableOpacity style={styles.followingItem} onPress={() => handleUserPress(item)}>
            <Image source={{ uri: item.profileImage }} style={styles.profileImage} />
            <View style={styles.followingInfo}>
                <Text style={styles.followingName}>{item.name}</Text>
            </View>
        </TouchableOpacity>
    );

    const handleUserPress = (item) => {
        if (currentUser._id === item._id) {
            navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
        } else {
            navigation.navigate('SocialUserPublicCars', { userId: item._id, userName: item.name, profileImage: item.profileImage });
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Following List</Text>
            <FlatList
                data={followingList}
                keyExtractor={(item) => item._id}
                renderItem={renderFollowingItem}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#F5F5F5',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    followingItem: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
        backgroundColor: 'white',
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#E0E0E0',
    },
    followingInfo: {
        flex: 1,
    },
    followingName: {
        fontSize: 16,
        fontWeight: 'bold',
    },
    profileImage: {
        width: 40, // Adjust the width and height as needed
        height: 40, // to fit your design
        borderRadius: 20, // Half of the width and height to make it circular
        marginRight: 10, // Spacing between image and text
    },
});

export default FollowingList;
