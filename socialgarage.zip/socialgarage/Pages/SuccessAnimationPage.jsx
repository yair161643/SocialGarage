import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import LottieView from 'lottie-react-native';

export default function SuccessAnimationPage({ route, navigation }) {
    const { newCar } = route.params;

    useEffect(() => {
        // Automatically navigate to ProfilePage with newCar after 2 seconds
        const timeout = setTimeout(() => {
            navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
        }, 2000);

        return () => clearTimeout(timeout); // Clear the timeout on unmount
    }, []);

    return (
        <View style={styles.container}>
            <View style={styles.animationContainer}>
                <LottieView
                    source={require('../lottieanimations/afterAddCarAnimation.json')} // Replace with your animation file
                    autoPlay
                    loop={false}
                    style={{ width: 200, height: 200 }}
                />
            </View>
        </View>
    );

}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    animationContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
});
