import React, { useContext, useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
  Alert,
  Image,
  KeyboardAvoidingView,
  ScrollView,
  Animated,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import cheerio from 'cheerio';
import LottieView from 'lottie-react-native';
import SuccessAnimationPage from './SuccessAnimationPage'; // Adjust the path as needed



export default function AddCar() {
  const navigation = useNavigation();
  const { addCarToUser, currentUser } = useContext(UserContext);

  const carList = [
    "אאודי",
    "אבארט",
    "אוטוביאנקי",
    "אולדסמוביל",
    "אוסטין",
    "אופל",
    "אורה",
    "איווייס",
    "איווקו",
    "אינפיניטי",
    "איסוזו",
    "אל.אי.וי.סי",
    "אל.טי.איי",
    "אלפא רומיאו",
    "אסטון מרטין",
    "אף. אי. דאבליו",
    "ב.מ.וו",
    "בי.ווי.די",
    "ביואיק",
    "בנטלי",
    "ג'י.איי.סי",
    "ג'י.איי.סי",
    "ג'י.אם.סי",
    "ג'יאו",
    "ג'ילי",
    "ג'יפ",
    "ג'יפ תע''ר",
    "ג'נסיס",
    "גרייט וול",
    "דאצ'יה",
    "דודג'",
    "דונגפנג",
    "די.אס",
    "דייהו",
    "דייהטסו",
    "האמר",
    "הונגצ'י",
    "הונדה",
    "הינו",
    "ווי",
    "וויה",
    "וולוו",
    "טאטא",
    "טויוטה",
    "טסלה",
    "יגואר",
    "יונדאי",
    "לאדה",
    "לינקולן",
    "ליפמוטור",
    "ליצ'י",
    "למבורגיני",
    "לנד רובר",
    "לנצ'יה",
    "לקסוס",
    "מאזדה",
    "מאן",
    "מזראטי",
    "מיני",
    "מיצובישי",
    "מקסוס",
    "מרצדס",
    "מ.ג",
    "ניסאן",
    "ננג'ינג",
    "סאאב",
    "סאן ליוינג",
    "סאנגיונג",
    "סאנשיין",
    "סובארו",
    "סוזוקי",
    "סיאט",
    "סיטרואן",
    "סמארט",
    "סנטרו",
    "סקודה",
    "סקייוול",
    "סרס",
    "פולסטאר",
    "פולקסווגן",
    "פונטיאק",
    "פורד",
    "פורשה",
    "פיאג'ו",
    "פיאט",
    "פיג'ו",
    "פרארי",
    "צ'רי",
    "קאדילק",
    "קופרה",
    "קיה",
    "קרייזלר",
    "רובר",
    "רנו",
    "שברולט",
  ];

  const [carNumber, setCarNumber] = useState('');
  const [carNumberEditable, setCarNumberEditable] = useState(true); // New state variable
  const [manufacturer, setManufacturer] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [mileage, setMileage] = useState('');
  const [license, setLicense] = useState('');
  const [test, setTest] = useState('');
  const [image, setImage] = useState(null);
  const [nickname, setNickname] = useState('');
  const [isUploading, setIsUploading] = useState(false);



  /* שליפת נתונים מאתר */    /* שליפת נתונים מאתר */   /* שליפת נתונים מאתר */   /* שליפת נתונים מאתר */
  const [web, setWeb] = useState(`https://data.gov.il/api/3/action/datastore_search?resource_id=053cea08-09bc-40ec-8f7a-156f0677aff3&q={"mispar_rechev": "`);
  const [data, setData] = useState(null);

  const pattern = /[0-9\\\-.,/]/g;

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  useEffect(() => {
    // Start the fade-in animation
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true,
    }).start();

    // Start the slide-up animation after the fade-in animation
    Animated.timing(slideAnim, {
      toValue: 0,
      duration: 800,
      useNativeDriver: true,
      delay: 200, // Delay the slide-up animation slightly after the fade-in animation starts
    }).start();
  }, []);



  const fetchData = async () => {
    try {
      setManufacturer("טוען נתונים, אנא המתן...");
      setModel("טוען נתונים, אנא המתן...");
      setYear("טוען נתונים, אנא המתן...");
      setTest("טוען נתונים, אנא המתן...");



      // שליחת הבקשה וקבלת התשובה
      const response = await fetch(web);
      const data = await response.json();
      const records = data.result.records[0];

      if (records) {

        const foundManufacturer = carList.find(manufacturer => records.tozeret_nm.includes(manufacturer));
        if (foundManufacturer) {
          setManufacturer(foundManufacturer);
        } else {
          setManufacturer(records.tozeret_nm);
        }
        
        setModel(records.kinuy_mishari);
        setYear(records.shnat_yitzur.toString());
        setTest(formatDate(records.tokef_dt));
      } else {
        alert('לא נמצא מידע עבור המספר רכב');
        navigation.navigate('TabbedPageNavigator');

      }
    } catch (error) {
      console.error(error);
    }
  };



  function formatDate(inputDate) {
    const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
    const dateParts = inputDate.split('-');
    const formattedDate = new Date(`${dateParts[0]}-${dateParts[1]}-${dateParts[2]}`).toLocaleDateString('he-IL', options);
    return formattedDate.replace(/\./g, '/'); // החלף את הנקודות בפסיקים
  }








  const handleAddCar = async () => {
    if (isNaN(carNumber) || parseInt(carNumber) !== Number(carNumber)) {
      Alert.alert('שגיאה', 'נא להקליד מספרים בלבד');
      return;
    }

    if (!image) {
      Alert.alert('שגיאה', 'נא להוסיף תמונה');
      return;
    }

    const newCar = {
      ownerId: currentUser._id,
      ownerName: currentUser.name,
      manufacturer: manufacturer,
      model: model,
      image: image,
      carNumber: carNumber,
      year: year,
      hand: license,
      currentMileage: mileage,
      testValidity: test,
      nickname: nickname,
      isPrivate: true, // מאותחל כפרטי, בשביל לא להציג את התמונות
      isForSale: false,
      tahzuka: [],
      cards: [],
    };

    const success = await addCarToUser(newCar);

    if (success) {
      // Reset the input fields
      setCarNumber('');
      setManufacturer('');
      setModel('');
      setYear('');
      setMileage('');
      setLicense('');
      setTest('');
      setImage(null);
      setNickname('');
      navigation.navigate('SuccessAnimationPage', { newCar });
    } else {
      Alert.alert('שגיאה', 'הרכב כבר רשום אצל משתמש אחר אם רכב זה בבעלותך אנא צור עימנו קשר');
    }
  };




  /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */ /* מצלמה\גלריה */
  const openImagePickerAsync = async () => {
    if (Platform.OS !== 'web') {
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (permissionResult.granted === false) {
        alert('נא לאשר גישה לגלריה ולמצלמה');
        return;
      }
    }

    Alert.alert(
      'בחר מקור תמונה',
      'בחר מקור לתמונה',
      [
        {
          text: 'מצלמה',
          onPress: () => launchCamera(),
        },
        {
          text: 'גלריה',
          onPress: () => launchGallery(),
        },
        {
          text: 'ביטול',
          style: 'cancel',
        },
      ],
      { cancelable: true }
    );
  };




  const launchCamera = async () => {
    let permissionResult = await ImagePicker.requestCameraPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("נדרשת הרשאה לגשת למצלמה!");
      return;
    }

    let pickerResult = await ImagePicker.launchCameraAsync({ base64: true, quality: 1.0 });

    if (!pickerResult.canceled) {
      await ImageUploader(pickerResult.assets[0].base64);
    }
  };





  //ask for permisstion
  const launchGallery = async () => {
    let permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("נדרשת הרשאה לגשת לגלריה!");
      return;
    }

    let pickerResult = await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 1.0 });

    if (!pickerResult.canceled) {
      await ImageUploader(pickerResult.assets[0].base64);
    }
  };


  const ImageUploader = async (uri) => {
    try {
      setIsUploading(true); // Set isUploading to true while the image is being uploaded

      const response = await fetch(`https://socialgarage.onrender.com/api/users/upload`, {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image: uri }),
      });

      if (!response.ok) {
        throw new Error("Failed to upload image");
      } else {
        const data = await response.json();
        setImage(data);
      }

      return;
    } catch (err) {
      console.log(err);
    } finally {
      setIsUploading(false); // Ensure isUploading is set back to false even if an error occurs
    }
  };





  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const dismissKeyboard = () => {
    Keyboard.dismiss();
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
      <ScrollView>
        <TouchableWithoutFeedback onPress={dismissKeyboard}>
          <Animated.View style={[styles.container, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>

            <View style={styles.container}>
              <Text style={styles.heading}>הוספת רכב</Text>


              <Text style={styles.upText}>מספר רכב</Text>

              <View style={styles.carNumberInputContainer}>

                <TouchableOpacity style={styles.confirmButton} onPress={() => {
                  fetchData();
                  setCarNumberEditable(false); // Disable car number input
                }}
                  disabled={!carNumberEditable} // Disable the button if input is disabled
                >
                  <Text style={styles.confirmButtonText}>אישור</Text>
                </TouchableOpacity>


                <TextInput
                  style={styles.inputNumberCar}
                  placeholder="מספר רכב"
                  keyboardType="numeric"
                  value={carNumber}
                  onChangeText={setCarNumber}
                  textAlign="right"
                  onBlur={() => setWeb(web + carNumber + `"}`)}
                  editable={carNumberEditable} // Set editable based on state
                />
              </View>

              <Text style={styles.upText}>יצרן</Text>
              <TextInput
                style={styles.input}
                placeholder="יצרן"
                value={manufacturer}
                onChangeText={setManufacturer}
                textAlign="right"
                editable={false}
              />

              <Text style={styles.upText}>דגם</Text>
              <TextInput
                style={styles.input}
                placeholder="דגם"
                value={model}
                onChangeText={setModel}
                textAlign="right"
                editable={false}
              />

              <Text style={styles.upText}>שנה</Text>
              <TextInput
                style={styles.input}
                placeholder="שנה"
                keyboardType="numeric"
                value={year}
                onChangeText={setYear}
                textAlign="right"
                editable={false}
              />

              <Text style={styles.upText}>תוקף טסט</Text>

              <TextInput
                style={styles.input}
                placeholder="תוקף טסט"
                value={test}
                onChangeText={setTest}
                textAlign="right"
                editable={false}
              />
              <Text style={styles.upText}>יד</Text>
              <TextInput
                style={styles.input}
                placeholder="יד נוכחית"
                keyboardType="numeric"
                value={license}
                onChangeText={setLicense}
                textAlign="right"
              />
              <Text style={styles.upText}>ק"מ</Text>
              <TextInput
                style={styles.input}
                placeholder="ק&quot;מ עדכני"
                keyboardType="numeric"
                value={mileage}
                onChangeText={setMileage}
                textAlign="right"
              />

              <Text style={styles.upText}>כינוי רכב</Text>
              <TextInput
                style={styles.input}
                placeholder="כינוי רכב"
                value={nickname}
                onChangeText={setNickname}
                textAlign="right"
              />

              {isUploading ? (
                <View style={[styles.loadingContainer, styles.centeredContainer]}>
                  <View style={styles.centeredContainer}>
                    <LottieView
                      source={require('../lottieanimations/theAddphotoLoad.json')} // Replace with the path to your Lottie JSON file
                      autoPlay
                      loop
                      style={{ width: 100, height: 100, marginRight: 20 }} // Adjust the size and margin as needed
                    />
                    <Text style={[styles.loadingText]}>מעלה תמונה, אנא המתן...</Text>
                  </View>
                </View>
              ) : (
                <TouchableOpacity style={styles.imageButton} onPress={openImagePickerAsync}>
                  <Text style={styles.buttonText}>בחר תמונה</Text>
                </TouchableOpacity>
              )}







              {image && (
                <View style={styles.imageContainer}>
                  <Text style={styles.imageText}>Selected Image:</Text>
                  <Image source={{ uri: image }} style={styles.selectedImage} />
                </View>
              )}

              <TouchableOpacity style={styles.addButton} onPress={handleAddCar}>
                <Text style={styles.addButtonText}>הוסף רכב</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </TouchableWithoutFeedback>
      </ScrollView>
    </KeyboardAvoidingView>
  );


}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    width: "100%",
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: "center",
  },
  carNumberInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: "100%",
  },
  confirmButton: {
    padding: 10,
    backgroundColor: '#ff5f04',
    borderRadius: 10,
    width: "25%",
    alignItems: "center",
    marginBottom: 11,

  },
  confirmButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',

  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
    borderColor: '#ff5f04',
    fontWeight: 'bold',
  },
  inputNumberCar: {
    marginLeft: 17.5,
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
    borderColor: '#ff5f04',
    fontWeight: 'bold',
    width: "70%",
  },
  imageButton: {
    marginTop: 10,
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#fff',  // שנה את צבע הרקע ללבן
    borderRadius: 5,  // שנה את הסגנון לעגול
    borderWidth: 1,  // הוסף מסגרת
    borderColor: '#ff5f04',  // צבע המסגרת
    fontWeight: 'bold',
    textAlign: 'center',  // מרכז את הטקסט באמצעות מיקום הטקסט
  },
  buttonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  imageText: {
    fontSize: 14,
    marginBottom: 5,
    textAlign: 'center',
  },
  selectedImage: {
    width: 200,
    height: 200,
    borderRadius: 10,
  },
  addButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#ff5f04',
    borderRadius: 10,
    alignSelf: 'center',
  },
  addButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  upText: {
    textAlign: "right",
    marginBottom: 3,
    marginRight: 3,
    fontWeight: 'bold',
  },
  centeredContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },

  loadingText: {
    fontSize: 14,
    marginTop: 5,
    textAlign: 'center',
  },
});